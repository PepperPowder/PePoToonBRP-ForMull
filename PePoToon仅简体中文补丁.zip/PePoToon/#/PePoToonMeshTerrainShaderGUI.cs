#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;
using System;
using System.Collections.Generic;

namespace UnityEditor{
	public class PePoToonMeshTerrainShaderGUI : ShaderGUI{
		Dictionary<string,string> langDict;
		bool groupMain=true;
		bool groupMain2=true;
		bool groupMain3=true;
		bool groupMain4=true;
		override public void OnGUI(MaterialEditor materialEditor,MaterialProperty[] properties) {
			if(langDict==null){SetLang();}
			Material material=materialEditor.target as Material;
			MaterialProperty mask=FindProperty("_Mask",properties);
			materialEditor.TexturePropertySingleLine(new GUIContent(langDict["mask"]),mask);
			EditorGUI.indentLevel++;
			materialEditor.TextureScaleOffsetProperty(mask);
			EditorGUI.indentLevel--;
			groupMain=EditorGUILayout.BeginFoldoutHeaderGroup(groupMain,langDict["groupMain"]);
			if(groupMain){DrawMain(materialEditor,properties);}
			EditorGUI.EndFoldoutHeaderGroup();
			groupMain2=EditorGUILayout.BeginFoldoutHeaderGroup(groupMain2,langDict["groupMain2"]);
			if(groupMain2){DrawMain(materialEditor,properties,"2");}
			EditorGUI.EndFoldoutHeaderGroup();
			groupMain3=EditorGUILayout.BeginFoldoutHeaderGroup(groupMain3,langDict["groupMain3"]);
			if(groupMain3){DrawMain(materialEditor,properties,"3");}
			EditorGUI.EndFoldoutHeaderGroup();
			groupMain4=EditorGUILayout.BeginFoldoutHeaderGroup(groupMain4,langDict["groupMain4"]);
			if(groupMain4){DrawMain(materialEditor,properties,"4");}
			EditorGUI.EndFoldoutHeaderGroup();
			GUILayout.Label(langDict["AdOp"], EditorStyles.boldLabel);
			materialEditor.RenderQueueField();
			materialEditor.EnableInstancingField();
		}
		private void DrawMain(MaterialEditor materialEditor,MaterialProperty[] properties,string ini=""){
			MaterialProperty mainTex=FindProperty("_MainTex"+ini,properties);
			MaterialProperty color=FindProperty("_Color"+ini,properties);
			MaterialProperty bumpMap=FindProperty("_BumpMap"+ini,properties);
			MaterialProperty bumpScale=FindProperty("_BumpScale"+ini,properties);
			MaterialProperty metallicGlossMap=FindProperty("_MetallicGlossMap"+ini,properties);
			MaterialProperty parallax=FindProperty("_Parallax"+ini,properties);
			MaterialProperty metallic=FindProperty("_Metallic"+ini,properties);
			MaterialProperty glossiness=FindProperty("_Glossiness"+ini,properties);
			if(ini==""){
				materialEditor.TexturePropertySingleLine(new GUIContent(langDict["mainTex2"]),mainTex,color);
			}else{
				materialEditor.TexturePropertySingleLine(new GUIContent(langDict["mainTex"]),mainTex,color);
			}
			EditorGUI.indentLevel++;
			materialEditor.TextureScaleOffsetProperty(mainTex);
			EditorGUI.indentLevel--;
			materialEditor.TexturePropertySingleLine(new GUIContent(langDict["bumpMap"]),bumpMap,bumpScale);
			materialEditor.TexturePropertySingleLine(new GUIContent(langDict["metallicGlossMap"]),metallicGlossMap);
			EditorGUI.indentLevel++;
			materialEditor.RangeProperty(parallax,langDict["parallax"]);
			materialEditor.RangeProperty(metallic,langDict["metallic"]);
			materialEditor.RangeProperty(glossiness,langDict["glossiness"]);
			EditorGUI.indentLevel--;
		}
		private void SetLang(){//设置语言，本人母语简体中文，非常不熟练英文
			langDict=new Dictionary<string,string>();
					langDict["mask"]="地形遮罩（Alpha参与裁剪）";
					langDict["groupMain"]="主要";
					langDict["groupMain2"]="红色";
					langDict["groupMain3"]="绿色";
					langDict["groupMain4"]="蓝色";
					langDict["mainTex"]="漫反射";
					langDict["mainTex2"]="漫反射（Alpha是裁剪）";
					langDict["bumpMap"]="法线贴图";
					langDict["metallicGlossMap"]="MHS遮罩";
					langDict["parallax"]="高度贴图（Green）";
					langDict["metallic"]="金属度（Red）";
					langDict["glossiness"]="平滑度（Blue）";
					langDict["AdOp"]="高级选项";
		}
	}
}
#endif