#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;
using System;
using System.Collections.Generic;

namespace UnityEditor{
	public class PePoToonMeshTerrainShaderGUI : ShaderGUI{
		Dictionary<string,string> langDict;
		bool groupMask=true;
		bool groupMask2=true;
		bool groupMain=true;
		bool groupMain2=true;
		bool groupMain3=true;
		bool groupMain4=true;
		bool groupMain5=true;
		bool groupMain6=true;
		bool groupMain7=true;
		bool groupMain8=true;
		override public void OnGUI(MaterialEditor materialEditor,MaterialProperty[] properties) {
			if(langDict==null){SetLang();}
			Material material=materialEditor.target as Material;
			groupMask=EditorGUILayout.BeginFoldoutHeaderGroup(groupMask,langDict["terrainMask1"]);
			if(groupMask){
				MaterialProperty terrainMask=FindProperty("_TerrainMask",properties);
				materialEditor.TexturePropertySingleLine(new GUIContent(langDict["terrainMask"]),terrainMask);
				groupMain=EditorGUILayout.Foldout(groupMain,langDict["main"]);
				if(groupMain){DrawMain(materialEditor,properties);}
				groupMain2=EditorGUILayout.Foldout(groupMain2,langDict["red"]);
				if(groupMain2){DrawMain(materialEditor,properties,"2");}
				groupMain3=EditorGUILayout.Foldout(groupMain3,langDict["green"]);
				if(groupMain3){DrawMain(materialEditor,properties,"3");}
				groupMain4=EditorGUILayout.Foldout(groupMain4,langDict["blue"]);
				if(groupMain4){DrawMain(materialEditor,properties,"4");}
			}EditorGUI.EndFoldoutHeaderGroup();
			groupMask2=EditorGUILayout.BeginFoldoutHeaderGroup(groupMask2,langDict["terrainMask2"]);
			if(groupMask2){
				MaterialProperty terrainMask2=FindProperty("_TerrainMask2",properties);
				materialEditor.TexturePropertySingleLine(new GUIContent(langDict["terrainMask2"]),terrainMask2);
				groupMain5=EditorGUILayout.Foldout(groupMain5,langDict["red"]);
				if(groupMain5){DrawMain(materialEditor,properties,"5");}
				groupMain6=EditorGUILayout.Foldout(groupMain6,langDict["green"]);
				if(groupMain6){DrawMain(materialEditor,properties,"6");}
				groupMain7=EditorGUILayout.Foldout(groupMain7,langDict["blue"]);
				if(groupMain7){DrawMain(materialEditor,properties,"7");}
				groupMain8=EditorGUILayout.Foldout(groupMain8,langDict["1-alpha"]);
				if(groupMain8){DrawMain(materialEditor,properties,"8");}
			}EditorGUI.EndFoldoutHeaderGroup();
			GUILayout.Label(langDict["AdOp"], EditorStyles.boldLabel);
			materialEditor.RenderQueueField();
			materialEditor.EnableInstancingField();
		}
		private void DrawMain(MaterialEditor materialEditor,MaterialProperty[] properties,string ini=""){
			MaterialProperty mainTex=FindProperty("_MainTex"+ini,properties);
			MaterialProperty color=FindProperty("_Color"+ini,properties);
			MaterialProperty bumpMap=FindProperty("_BumpMap"+ini,properties);
			MaterialProperty bumpScale=FindProperty("_BumpScale"+ini,properties);
			MaterialProperty metallicGlossMap=FindProperty("_MetallicGlossMap"+ini,properties);
			MaterialProperty parallax=FindProperty("_Parallax"+ini,properties);
			MaterialProperty metallic=FindProperty("_Metallic"+ini,properties);
			MaterialProperty glossiness=FindProperty("_Glossiness"+ini,properties);
			if(ini==""){
				materialEditor.TexturePropertySingleLine(new GUIContent(langDict["mainTex2"]),mainTex,color);
			}else{
				materialEditor.TexturePropertySingleLine(new GUIContent(langDict["mainTex"]),mainTex,color);
			}
			EditorGUI.indentLevel++;
			materialEditor.TextureScaleOffsetProperty(mainTex);
			EditorGUI.indentLevel--;
			materialEditor.TexturePropertySingleLine(new GUIContent(langDict["bumpMap"]),bumpMap,bumpScale);
			materialEditor.TexturePropertySingleLine(new GUIContent(langDict["metallicGlossMap"]),metallicGlossMap);
			EditorGUI.indentLevel++;
			materialEditor.RangeProperty(parallax,langDict["parallax"]);
			materialEditor.RangeProperty(metallic,langDict["metallic"]);
			materialEditor.RangeProperty(glossiness,langDict["glossiness"]);
			EditorGUI.indentLevel--;
		}
		private void SetLang(){//设置语言，本人母语简体中文，非常不熟练英文
			langDict=new Dictionary<string,string>();
					langDict["terrainMask"]="地形遮罩（A参与裁剪）";
					langDict["terrainMask1"]="地形遮罩";
					langDict["terrainMask2"]="地形遮罩2";
					langDict["main"]="主要";
					langDict["red"]="R";
					langDict["green"]="G";
					langDict["blue"]="B";
					langDict["1-alpha"]="1-A";
					langDict["mainTex"]="漫反射";
					langDict["mainTex2"]="漫反射（A是裁剪）";
					langDict["bumpMap"]="法线贴图";
					langDict["metallicGlossMap"]="MHS遮罩";
					langDict["parallax"]="高度贴图（G）";
					langDict["metallic"]="金属度（R）";
					langDict["glossiness"]="平滑度（B）";
					langDict["AdOp"]="高级选项";
		}
	}
}
#endif