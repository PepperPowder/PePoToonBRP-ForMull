#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;
using System;
using System.Collections.Generic;

namespace UnityEditor{
	public class PePoToonShaderGUI : ShaderGUI{
		Dictionary<string,string> langDict;
		int rend;
		bool groupAdOp=true;
		bool groupStencil=true;
		bool groupMain=true;
		bool groupOut=true;
		bool groupEmis=true;
		bool groupAmb=true;
		override public void OnGUI(MaterialEditor materialEditor,MaterialProperty[] properties) {
			//base.OnGUI(materialEditor,properties);
			if(langDict==null){SetLang();}
			groupAdOp=EditorGUILayout.BeginFoldoutHeaderGroup(groupAdOp,langDict["groupAdOp"]);
			if(groupAdOp){
				Material material=materialEditor.target as Material;
				MaterialProperty mode=FindProperty("_Mode",properties);
				MaterialProperty cutoff=FindProperty("_Cutoff",properties);
				MaterialProperty zWrite=FindProperty("_ZWrite",properties,false);
				MaterialProperty srcBlend=FindProperty("_SrcBlend",properties,false);
				MaterialProperty dstBlend=FindProperty("_DstBlend",properties,false);
				EditorGUI.BeginChangeCheck();
				materialEditor.ShaderProperty(mode,langDict["mode"]);
				rend=(int)mode.floatValue;
				if(EditorGUI.EndChangeCheck()){SetQueue(material,cutoff.floatValue,zWrite.displayName=="1",true);}
				EditorGUI.indentLevel++;
				EditorGUI.BeginChangeCheck();
				materialEditor.ShaderProperty(cutoff,langDict["cutoff"]);
				if(EditorGUI.EndChangeCheck() && rend<2){SetQueue(material,cutoff.floatValue,zWrite.displayName=="1",true);}
				materialEditor.ShaderProperty(zWrite,"ZWrite");
				materialEditor.ShaderProperty(srcBlend,"SrcBlend");
				materialEditor.ShaderProperty(dstBlend,"DstBlend");
				materialEditor.RenderQueueField();
				SetQueue(material,cutoff.floatValue,zWrite.displayName=="1");
				EditorGUI.indentLevel--;
				MaterialProperty cull=FindProperty("_Cull",properties,false);
				if(cull!=null){materialEditor.ShaderProperty(cull,langDict["cull"]);}
				EditorGUI.indentLevel++;
				MaterialProperty reverseNormal=FindProperty("_ReverseNormal",properties,false);
				MaterialProperty outTex=FindProperty("_OutTex",properties,false);
				if(reverseNormal!=null &&(cull==null || cull.floatValue<2 || outTex!=null)){
					materialEditor.ShaderProperty(reverseNormal,langDict["reverseNormal"]);
				}
				EditorGUI.indentLevel--;
				MaterialProperty castShadows=FindProperty("_CastShadows",properties);
				materialEditor.ShaderProperty(castShadows,langDict["castShadows"]);
				materialEditor.EnableInstancingField();
			}
			EditorGUI.EndFoldoutHeaderGroup();
			//DrawStencil(materialEditor,properties);
			DrawMain(materialEditor,properties);
			DrawEmis(materialEditor,properties);
			DrawAmb(materialEditor,properties);
		}
		private void DrawStencil(MaterialEditor materialEditor,MaterialProperty[] properties){//遮罩相关
			MaterialProperty zTest=FindProperty("_ZTest",properties,false);
			if(zTest!=null){
				MaterialProperty stencil=FindProperty("_Stencil",properties,false);
				MaterialProperty stencilComp=FindProperty("_StencilComp",properties,false);
				MaterialProperty stencilOp=FindProperty("_StencilOp",properties,false);
				groupStencil=EditorGUILayout.BeginFoldoutHeaderGroup(groupStencil,langDict["stencil"]);
				if(groupStencil){
					EditorGUI.indentLevel++;
					materialEditor.ShaderProperty(zTest,"ZTest");
					EditorGUILayout.Space(10);
					materialEditor.ShaderProperty(stencil,langDict["stencil"]);
					EditorGUI.indentLevel++;
					materialEditor.ShaderProperty(stencilComp,langDict["stencilComp"]);
					materialEditor.ShaderProperty(stencilOp,langDict["stencilOp"]);
					EditorGUI.indentLevel--;
					EditorGUI.indentLevel--;
				}
				EditorGUI.EndFoldoutHeaderGroup();
			}
		}
		private void DrawMain(MaterialEditor materialEditor,MaterialProperty[] properties){//绘制漫反射贴图界面
			MaterialProperty mode=FindProperty("_Mode",properties);
			MaterialProperty cull=FindProperty("_Cull",properties,false);
			MaterialProperty mainTex=FindProperty("_MainTex",properties);
			MaterialProperty color=FindProperty("_Color",properties);
			MaterialProperty mainTex2=FindProperty("_MainTex2",properties,false);
			MaterialProperty mainTex2Alpha=FindProperty("_MainTex2Alpha",properties,false);
			MaterialProperty mainTex2Type=FindProperty("_MainTex2Type",properties,false);
			MaterialProperty mainTex3=FindProperty("_MainTex3",properties,false);
			MaterialProperty mainTex3Alpha=FindProperty("_MainTex3Alpha",properties,false);
			MaterialProperty mainTex3Type=FindProperty("_MainTex3Type",properties,false);
			MaterialProperty bumpMap=FindProperty("_BumpMap",properties,false);
			MaterialProperty bumpScale=FindProperty("_BumpScale",properties,false);
			MaterialProperty parallaxMap=FindProperty("_ParallaxMap",properties,false);
			MaterialProperty parallax=FindProperty("_Parallax",properties,false);
			MaterialProperty parallaxChannel=FindProperty("_ParallaxChannel",properties,false);
			MaterialProperty outTex=FindProperty("_OutTex",properties,false);
			MaterialProperty outColor=FindProperty("_OutColor",properties,false);
			MaterialProperty mainAsOut=FindProperty("_MainAsOut",properties,false);
			MaterialProperty outMask=FindProperty("_OutMask",properties,false);
			MaterialProperty outMaskChannel=FindProperty("_OutMaskChannel",properties,false);
			MaterialProperty outWidth=FindProperty("_OutWidth",properties,false);
			MaterialProperty outWidthCut=FindProperty("_OutWidthCut",properties,false);
			MaterialProperty softParticlesFarFadeDistance=FindProperty("_SoftParticlesFarFadeDistance",properties,false);
			MaterialProperty cameraFarFadeDistance=FindProperty("_CameraFarFadeDistance",properties,false);
			MaterialProperty cameraSoftAngle=FindProperty("_CameraSoftAngle",properties,false);
			MaterialProperty waterUseUv=FindProperty("_WaterUseUv",properties,false);
			MaterialProperty waterScale=FindProperty("_WaterScale",properties,false);
			MaterialProperty waterSpeed=FindProperty("_WaterSpeed",properties,false);
			MaterialProperty waterVis=FindProperty("_WaterVis",properties,false);
			MaterialProperty cameraFarFade=FindProperty("_CameraFarFade",properties,false);
			MaterialProperty asSkybox=FindProperty("_AsSkybox",properties,false);
			MaterialProperty cloudsDir=FindProperty("_CloudsDir",properties,false);
			MaterialProperty flipbookMode=FindProperty("_FlipbookMode",properties,false);
			MaterialProperty sprite=FindProperty("_Sprite",properties,false);
			groupMain=EditorGUILayout.BeginFoldoutHeaderGroup(groupMain,langDict["groupMain"]);
			if(groupMain){
				materialEditor.TexturePropertySingleLine(new GUIContent(langDict["mainTex"]),mainTex,color);
				EditorGUI.indentLevel++;
				materialEditor.TextureScaleOffsetProperty(mainTex);
				if(mainTex2Type!=null){
					materialEditor.TexturePropertySingleLine(new GUIContent(langDict["mainTex2"]),mainTex2,mainTex2Alpha,mainTex2Type);
					if(mainTex2Alpha.floatValue>0 && mainTex2Type.floatValue>0 && mainTex2.textureValue!=null){
						EditorGUI.indentLevel++;
						materialEditor.TextureScaleOffsetProperty(mainTex2);
						EditorGUI.indentLevel--;
					}
					materialEditor.TexturePropertySingleLine(new GUIContent(langDict["mainTex3"]),mainTex3,mainTex3Alpha,mainTex3Type);
					if(mainTex3Alpha.floatValue>0 && mainTex3Type.floatValue>0 && mainTex3.textureValue!=null){
						EditorGUI.indentLevel++;
						materialEditor.TextureScaleOffsetProperty(mainTex3);
						EditorGUI.indentLevel--;
					}
				}
				EditorGUI.indentLevel--;
				if(bumpMap!=null){
					materialEditor.TexturePropertySingleLine(new GUIContent(langDict["bumpMap"]),bumpMap,bumpScale);
				}
				if(parallaxMap!=null){
					materialEditor.TexturePropertySingleLine(new GUIContent(langDict["parallaxMap"]),parallaxMap,parallax,parallaxChannel);
				}else if(parallax!=null){
					materialEditor.ShaderProperty(parallax,langDict["zeroPoint"]);
				}
				if(flipbookMode!=null){
					materialEditor.ShaderProperty(flipbookMode,langDict["flipbook"]);
					materialEditor.ShaderProperty(sprite,langDict["sprite"]);
				}
				if(rend>1){
					if(softParticlesFarFadeDistance!=null){materialEditor.ShaderProperty(softParticlesFarFadeDistance,langDict["softEdge"]);}
					if(cameraFarFadeDistance!=null){materialEditor.ShaderProperty(cameraFarFadeDistance,langDict["cameraSoftEdge"]);}
					if(cameraSoftAngle!=null){materialEditor.ShaderProperty(cameraSoftAngle,langDict["cameraSoftAngle"]);}
					if(cameraFarFade!=null){materialEditor.ShaderProperty(cameraFarFade,langDict["cameraFarFade"]);}
					if(asSkybox!=null){materialEditor.ShaderProperty(asSkybox,langDict["asSkybox"]);}
				}
			}
			EditorGUI.EndFoldoutHeaderGroup();
			if(outTex!=null){
				groupOut=EditorGUILayout.BeginFoldoutHeaderGroup(groupOut,langDict["groupOut"]);
				if(groupOut){
					materialEditor.TexturePropertySingleLine(new GUIContent(langDict["outTex"]),outTex,outColor);
					EditorGUI.indentLevel++;
					materialEditor.ShaderProperty(mainAsOut,langDict["mainAsOut"]);
					EditorGUI.indentLevel--;
					materialEditor.TexturePropertySingleLine(new GUIContent(langDict["outWidth"]),outMask,outWidth,outMaskChannel);
					EditorGUI.indentLevel++;
					materialEditor.ShaderProperty(outWidthCut,langDict["outWidthCut"]);
					EditorGUI.indentLevel--;
				}
				EditorGUI.EndFoldoutHeaderGroup();
			}
			if(waterVis!=null){
				groupOut=EditorGUILayout.BeginFoldoutHeaderGroup(groupOut,langDict["groupWater"]);
				if(groupOut){
					MaterialProperty stencil=FindProperty("_Stencil",properties,false);
					if(stencil!=null){materialEditor.ShaderProperty(stencil,langDict["stencil"]);}
					materialEditor.ShaderProperty(bumpScale,langDict["height"]);
					if(bumpScale.floatValue>0){
						EditorGUI.indentLevel++;
						materialEditor.ShaderProperty(waterUseUv,langDict["useUv"]);
						materialEditor.ShaderProperty(waterScale,langDict["scale"]);
						materialEditor.ShaderProperty(waterSpeed,langDict["speed"]);
						EditorGUI.indentLevel--;
					}
					if(rend>1){
						materialEditor.ShaderProperty(waterVis,langDict["waterVis"]);
					}
				}
				EditorGUI.EndFoldoutHeaderGroup();
			}
			if(cloudsDir!=null){
				groupOut=EditorGUILayout.BeginFoldoutHeaderGroup(groupOut,langDict["groupClouds"]);
				if(groupOut){
					materialEditor.ShaderProperty(bumpScale,langDict["density"]);
					if(bumpScale.floatValue<1){
						EditorGUI.indentLevel++;
						materialEditor.ShaderProperty(waterUseUv,langDict["useUv"]);
						materialEditor.ShaderProperty(waterScale,langDict["scale"]);
						materialEditor.ShaderProperty(waterSpeed,langDict["speed"]);
						materialEditor.ShaderProperty(cloudsDir,langDict["dir"]);
						EditorGUI.indentLevel--;
					}
				}
				EditorGUI.EndFoldoutHeaderGroup();
			}
		}
		private void DrawEmis(MaterialEditor materialEditor,MaterialProperty[] properties){
			MaterialProperty emissionColor=FindProperty("_EmissionColor",properties);
			MaterialProperty emissionMap=FindProperty("_EmissionMap",properties);
			MaterialProperty mainAsEmis=FindProperty("_MainAsEmis",properties);
			MaterialProperty emissionOut=FindProperty("_EmissionOut",properties,false);
			MaterialProperty flipbookMode=FindProperty("_FlipbookMode",properties,false);
			groupEmis=EditorGUILayout.BeginFoldoutHeaderGroup(groupEmis,langDict["groupEmis"]);
			if(groupEmis){
				if(mainAsEmis.floatValue==0){
					materialEditor.TexturePropertyWithHDRColor(new GUIContent(langDict["emissionTex"]),emissionMap,emissionColor,false);
				}else{
					materialEditor.TexturePropertyWithHDRColor(new GUIContent(langDict["emissionMap"]),emissionMap,emissionColor,false);
				}
				if(emissionColor.colorValue.r+emissionColor.colorValue.g+emissionColor.colorValue.b>0){
					EditorGUI.indentLevel++;
					materialEditor.ShaderProperty(mainAsEmis,langDict["mainAsEmis"]);
					if(emissionOut!=null){
						materialEditor.ShaderProperty(emissionOut,langDict["effectOut"]);
					}
					EditorGUI.indentLevel--;
				}
				if(flipbookMode==null){
					EditorGUI.BeginChangeCheck();
					materialEditor.LightmapEmissionProperty();
					if (EditorGUI.EndChangeCheck()){
						foreach (Material m in materialEditor.targets){
							m.globalIlluminationFlags &= ~MaterialGlobalIlluminationFlags.EmissiveIsBlack;
						}
					}
					materialEditor.DoubleSidedGIField();
				}
			}
			EditorGUI.EndFoldoutHeaderGroup();
		}
		private void DrawAmb(MaterialEditor materialEditor,MaterialProperty[] properties){
			MaterialProperty brightness=FindProperty("_Brightness",properties);
			MaterialProperty lit=FindProperty("_Lit",properties);
			MaterialProperty lightProbeDir=FindProperty("_LightProbeDir",properties);
			MaterialProperty receiveShadows=FindProperty("_ReceiveShadows",properties,false);
			MaterialProperty shadows=FindProperty("_Shadows",properties);
			MaterialProperty shadowsRange=FindProperty("_ShadowsRange",properties);
			MaterialProperty shadowsSmooth=FindProperty("_ShadowsSmooth",properties);
			MaterialProperty metallicGlossMap=FindProperty("_MetallicGlossMap",properties);
			MaterialProperty metallicGlossMode=FindProperty("_MetallicGlossMode",properties);
			MaterialProperty metallic=FindProperty("_Metallic",properties);
			MaterialProperty metallicChannel=FindProperty("_MetallicChannel",properties);
			MaterialProperty glossiness=FindProperty("_Glossiness",properties);
			MaterialProperty glossinessChannel=FindProperty("_GlossinessChannel",properties);
			groupAmb=EditorGUILayout.BeginFoldoutHeaderGroup(groupAmb,langDict["groupAmb"]);
			if(groupAmb){
				materialEditor.ShaderProperty(brightness,langDict["brightness"]);
				materialEditor.ShaderProperty(lit,langDict["lit"]);
				if(lit.floatValue>0){
					materialEditor.ShaderProperty(lightProbeDir,langDict["lightProbeDir"]);
					if(receiveShadows!=null){materialEditor.ShaderProperty(receiveShadows,langDict["receiveShadows"]);}
					materialEditor.ShaderProperty(shadows,langDict["shadows"]);
					if(shadows.floatValue>0){
						EditorGUI.indentLevel++;
						materialEditor.ShaderProperty(shadowsRange,langDict["range"]);
						materialEditor.ShaderProperty(shadowsSmooth,langDict["smooth"]);
						EditorGUI.indentLevel--;
					}
					materialEditor.TexturePropertySingleLine(new GUIContent(langDict["metallicGlossMap"]),metallicGlossMap,metallicGlossMode);
					if(metallicGlossMode.floatValue>0){
						EditorGUI.indentLevel++;
						materialEditor.TexturePropertySingleLine(new GUIContent(langDict["metallic"]),metallicGlossMap,metallic,metallicChannel);
						materialEditor.TexturePropertySingleLine(new GUIContent(langDict["glossiness"]),metallicGlossMap,glossiness,glossinessChannel);
						EditorGUI.indentLevel--;
					}
				}
			}
			EditorGUI.EndFoldoutHeaderGroup();
		}
		private void SetQueue(Material material,float cutoff,bool zWriteOn,bool rendChange=false){//设置渲染队列2000、2450、3000
			switch(rend){
				case 0:{//不透明Opaque
					if(cutoff>0){goto case 1;}
					if(rendChange || material.renderQueue==(int)UnityEngine.Rendering.RenderQueue.Background){
						material.renderQueue=(int)UnityEngine.Rendering.RenderQueue.Geometry;
						material.SetInt("_ZWrite",1);
						material.SetInt("_SrcBlend",(int)UnityEngine.Rendering.BlendMode.One);
						material.SetInt("_DstBlend",(int)UnityEngine.Rendering.BlendMode.Zero);
						material.SetOverrideTag("RenderType", "Opaque");
					}
					break;
				}
				case 1:{//裁剪Cutout
					if(rendChange || material.renderQueue==(int)UnityEngine.Rendering.RenderQueue.Background){
						material.renderQueue=(int)UnityEngine.Rendering.RenderQueue.AlphaTest;
						material.SetInt("_ZWrite",1);
						material.SetInt("_SrcBlend",(int)UnityEngine.Rendering.BlendMode.One);
						material.SetInt("_DstBlend",(int)UnityEngine.Rendering.BlendMode.Zero);
						material.SetOverrideTag("RenderType", "TransparentCutout");
					}
					break;
				}
				case 2:{//透明Fade
					if(rendChange || material.renderQueue==(int)UnityEngine.Rendering.RenderQueue.Background){
						material.renderQueue=(int)UnityEngine.Rendering.RenderQueue.Transparent;
						if(zWriteOn){material.SetInt("_ZWrite",1);}else{material.SetInt("_ZWrite",0);}
						material.SetInt("_SrcBlend",(int)UnityEngine.Rendering.BlendMode.SrcAlpha);
						material.SetInt("_DstBlend",(int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
						material.SetOverrideTag("RenderType", "Transparent");
					}
					break;
				}
				case 3:{//透明Transparent
					if(rendChange || material.renderQueue==(int)UnityEngine.Rendering.RenderQueue.Background){
						material.renderQueue=(int)UnityEngine.Rendering.RenderQueue.Transparent;
						if(zWriteOn){material.SetInt("_ZWrite",1);}else{material.SetInt("_ZWrite",0);}
						material.SetInt("_SrcBlend",(int)UnityEngine.Rendering.BlendMode.One);
						material.SetInt("_DstBlend",(int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
						material.SetOverrideTag("RenderType", "Transparent");
					}
					break;
				}
				case 4:{//相加Additive
					if(rendChange || material.renderQueue==(int)UnityEngine.Rendering.RenderQueue.Background){
						material.renderQueue=(int)UnityEngine.Rendering.RenderQueue.Transparent;
						if(zWriteOn){material.SetInt("_ZWrite",1);}else{material.SetInt("_ZWrite",0);}
						material.SetInt("_SrcBlend",(int)UnityEngine.Rendering.BlendMode.SrcAlpha);
						material.SetInt("_DstBlend",(int)UnityEngine.Rendering.BlendMode.One);
						material.SetOverrideTag("RenderType", "Transparent");
					}
					break;
				}
				case 5:{goto case 4;}//相减Subtractive
				case 6:{//相乘Multiply
					if(rendChange || material.renderQueue==(int)UnityEngine.Rendering.RenderQueue.Background){
						material.renderQueue=(int)UnityEngine.Rendering.RenderQueue.Transparent;
						if(zWriteOn){material.SetInt("_ZWrite",1);}else{material.SetInt("_ZWrite",0);}
						material.SetInt("_SrcBlend",(int)UnityEngine.Rendering.BlendMode.DstColor);
						material.SetInt("_DstBlend",(int)UnityEngine.Rendering.BlendMode.Zero);
						material.SetOverrideTag("RenderType", "Transparent");
					}
					break;
				}
				default:{
					goto case 0;
				}
			}
		}
		private void SetLang(){//设置语言，本人母语简体中文，非常不熟练英文
			langDict=new Dictionary<string,string>();
					langDict["groupAdOp"]="高级选项";
					langDict["mode"]="渲染模式";
					langDict["cull"]="面剔除";
					langDict["castShadows"]="投射阴影";
					langDict["stencil"]="模板";
					langDict["stencilComp"]="读取";
					langDict["stencilOp"]="写入";
					langDict["groupMain"]="漫反射";
					langDict["mainTex"]="主帖图";
					langDict["cutoff"]="透明度裁剪";
					langDict["mainTex2"]="贴图2";
					langDict["mainTex3"]="贴图3";
					langDict["bumpMap"]="法线贴图";
					langDict["reverseNormal"]="反转背面";
					langDict["parallaxMap"]="高度贴图";
					langDict["groupOut"]="外轮廓";
					langDict["outTex"]="外轮廓贴图";
					langDict["mainAsOut"]="与主帖图相乘";
					langDict["outWidth"]="外轮廓宽度";
					langDict["outWidthCut"]="裁剪0宽度";
					langDict["brightness"]="亮度";
					langDict["groupEmis"]="自发光";
					langDict["emissionTex"]="自发光贴图";
					langDict["emissionMap"]="自发光遮罩";
					langDict["mainAsEmis"]="自发光方式";
					langDict["effectOut"]="影响外轮廓";
					langDict["groupAmb"]="环境光照";
					langDict["lit"]="光照着色";
					langDict["lightProbeDir"]="光照探针方向";
					langDict["receiveShadows"]="接收阴影";
					langDict["shadows"]="法线阴影";
					langDict["range"]="范围";
					langDict["smooth"]="平滑";
					langDict["metallicGlossMap"]="高光反射";
					langDict["metallic"]="金属度";
					langDict["glossiness"]="平滑度";
					langDict["softEdge"]="软边缘（需要摄像机深度）";
					langDict["cameraSoftEdge"]="摄像机软边缘";
					langDict["cameraSoftAngle"]="摄像机软角度";
					langDict["groupWater"]="水";
					langDict["height"]="高度";
					langDict["useUv"]="使用UV";
					langDict["speed"]="速度";
					langDict["scale"]="缩放";
					langDict["waterVis"]="能见度（需要摄像机深度）";
					langDict["asSkybox"]="作为天空盒";
					langDict["cameraFarFade"]="摄像机远截面淡出";
					langDict["groupClouds"]="云";
					langDict["density"]="密度";
					langDict["dir"]="方向";
					langDict["zeroPoint"]="归零点";
					langDict["flipbook"]="帧融合";
					langDict["sprite"]="精灵图";
		}
	}
}
#endif